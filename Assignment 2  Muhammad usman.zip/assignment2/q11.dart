void main (){

  List originalList  = ['pakistan' ,'karachi','islamabad' , 'lahore','gilgit','india','mumbai','austrailia','sydney'];
  var newlist = [...originalList.reversed];

  // newlist.reversed();
  print(originalList);
  print(newlist);
}