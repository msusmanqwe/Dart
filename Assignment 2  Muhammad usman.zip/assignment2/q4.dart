void main (){

List num1 = [1,6,3,74,58,60,73,83,19,99];

num1.sort();
var firstNum = num1.first;
var lastNum = num1.last;

print('this smallest number ${firstNum}');
print('this greatest number ${lastNum}');
}