
void main(){


  List numberList = [88,9,86,67,456,345,657,7878,434,23436,6587698,12,312,435,46,7,68,785,6,4,33,1,21,312,423,4];


   numberList.sort();
   var maxNumber = numberList.last;
   print(maxNumber);
}