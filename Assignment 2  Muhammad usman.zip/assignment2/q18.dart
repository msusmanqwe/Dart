void main()
{


Map stockmanagement = {

 "name": 'mobile',
"price":25000,
"quantity" : 12
};

if (stockmanagement['quantity'] > 0){
  print('product is available');
}else{
  print('product is not available');
}

}