void main()

{
  List originalList = [9,8,7,76,6,41,5,13,4,21,3,2,1,2,3,4,78,12,1];

  List newlist = [...originalList];
  newlist.sort();
  print(originalList);
  print(newlist);
}