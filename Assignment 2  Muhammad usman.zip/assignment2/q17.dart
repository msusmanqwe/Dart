void main ()
{
  Map person = {
    'name':'jhon',
    'age': 25,
    'student': true
  };

  if (person['age']>= 18 || person['student'] == true){

    print('this stdent is eligible');
  }
  else{
    print('this student is not eligible');
  }

}