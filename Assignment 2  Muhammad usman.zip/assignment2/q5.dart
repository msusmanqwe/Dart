void main (){

Map map1  = {
  "name": "hammas shahzad shani",
  "phone": 0311-1809562
};

var  keyoflenght  = map1.entries.where((element) => element.key.length == 4);

print(keyoflenght);


// Map people = {
//  "name": "hammas shahzad shani",
//   "phone": 0311-1809562
// };

// // Filter people older than 25 (key-value pairs)
// var filteredPeople = people.entries.where((entry) => entry.key.length  == 4 );

// print(filteredPeople);




}