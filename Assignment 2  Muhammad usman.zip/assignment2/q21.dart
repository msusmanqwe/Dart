void main()
{
  Map product = {

    // 'apple':3,
    'banana':4,
    'mango':10
  };
  
if(product.containsKey('apple')){

  print('apple is exist');
}else{
  print('apple not exist');
}
}