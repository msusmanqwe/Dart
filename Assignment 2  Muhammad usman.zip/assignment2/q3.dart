void main (){

 List weekDays =['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
 weekDays.removeWhere((element) => element.length > 0);
 print(weekDays);
}