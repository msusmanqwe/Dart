void main()
{

  Map adminActive = {
    'name': 'Admin',
    'active': false
  };

  if(adminActive['name']== 'Admin' && adminActive['active']== true){
    print('Admin Active');
  }else{
    print('Not an active admin');
  }

}