void main(){

  List weekDays = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday','monday','tuesday','wednesday','thursday','friday','saturday','sunday''monday','tuesday','wednesday','thursday','friday','saturday','sunday''monday','tuesday','wednesday','thursday','friday','saturday','sunday''monday','tuesday','wednesday','thursday','friday','saturday','sunday'];
  var newlist = weekDays.toSet().toList();
  print(newlist);

}