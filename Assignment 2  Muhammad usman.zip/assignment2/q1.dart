void main(){

  var studentName = ["hammas","sarib","Usman","Rizwan","hammad","abbas"];
  print(studentName);

final studentNames = ["hammas","sarib","Usman","Rizwan","hammad","abbas"];
studentNames.forEach((name) => print(name));

  
}