void main()
{

    Map car = {
    'name':'toyota',
    'sedan': true,
    'color': 'red'
  };

  if (car['sedan'] ==  true && car['color'] == 'red'){

    print('match');
  }
  else{
    print('no match');
  }

}