void main()
{
  List numberList = [2,3,4,5,6,7,8,9,0,21,32,34,54,86];

List newnumberList  = [...numberList];

var newlist = newnumberList.where((element) => element%2 == 0  );

print(numberList);
print(newlist);

}