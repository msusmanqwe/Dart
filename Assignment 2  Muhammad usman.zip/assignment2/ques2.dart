void main (){

  List weekDays = [];

  weekDays.addAll(['monday','tuesday','wednesday','thursday','friday','saturday','sunday']);
  print(weekDays);

  weekDays.forEach((element) => print(element)); // second way to print list 
}