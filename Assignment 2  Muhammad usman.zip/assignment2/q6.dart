
import 'dart:io';
void main() {

  print("Enter your Country name: ");
  final name = stdin.readLineSync()!;
  // print("Hello, $name!");

  Map world = {
    "countries": {
      "pakistan": {
        "Country name": "Pakistan",
        "capital": "Islamabad",
        "currency": "Rupees",
        "language": "Urdu",
      },
      "japan": {
        "Country name": "japan",
        "capital": "Tokyo",
        "currency": "Yen",
        "language": "Japanese",
      },
      "india": {
        "Country name": "India",
        "capital": "New Delhi",
        "currency": "Rupees",
        "language": "Hindi",
      },
    },
  };
  var countryValues = world['countries']['$name'];
  print(countryValues);
}
