void main()
{
  List numberList = [-1,2,-3,4,2,-4,7,1,-1,-4,-1];

List newnumberList  = [...numberList];

var newlist = newnumberList.where((element) => element > 0 );

print(numberList);
print(newlist);

}