void main (){


List originalList = [1,2,3,4,5,6,7,8,99,12,2,3,4,5,67,89,9,9,1,3,5,6];

var newlist =  [...originalList.toSet().toList()];

print(originalList);
print(newlist);


}
