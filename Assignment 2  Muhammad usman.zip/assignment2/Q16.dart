
void main()
{
  List numberList = [2,3,4,5,6,7,8,9,0,21,32,34,54,86];

 List squareList =  numberList.map((e) =>  e * e).toList();

 print(squareList);


}